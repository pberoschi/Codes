# temperature_logger
Temperature is updaten on thinkspeak channel using gms module
